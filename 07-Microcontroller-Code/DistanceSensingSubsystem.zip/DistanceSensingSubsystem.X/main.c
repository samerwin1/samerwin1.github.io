 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "stdio.h"
#include "stdlib.h"

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    //INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 
    
    int16_t Rotary_value;      //Rotary encoder value
    int16_t Sensor1_value;     //Sensor on opening face of door
    int16_t Sensor1_initial;   //Initial Sensor1 value
    int16_t Sensor2_value;     //Sensor on closing face of door
    int16_t Sensor2_initial;   //Initial Sensor2 value
    int16_t Sensor1_index[10]; //Sensor1 list of values matched to encoder
    int16_t Sensor2_index[10]; //Sensor2 list of values matched to encoder
    int16_t Rotary_previous;   //Used to store previous rotary value
    int calibrate = 1;         //Used to determine if calibration block should be entered
    int x;                     //Used to reference index values
    ADC_Initialize();
    ADC_ChannelSelect(ADC_CHANNEL_ANA0);
    ADC_ConversionStart();
    

    while (CALIBRATE_GetValue() == 0){  //Upon startup, wait for calibration to be triggered
    }
    
    
    while(1)
    {
        if (calibrate == 1){    //Begin Calibration
            calibrate = 0;
            ADC_SampleCapacitorDischarge();
            __delay_us(5);
            Sensor1_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA0);  //Store value of sensor 1 when door is closed
            Sensor1_index[0] = Sensor1_value;
            Sensor1_initial = Sensor1_value;
            ADC_SampleCapacitorDischarge();
            __delay_us(5);
            Sensor1_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA1);  //Store value of sensor 2 when door is closed
            Sensor2_index[0] = Sensor2_value;
            Sensor2_initial = Sensor2_value;
            
            ADC_SampleCapacitorDischarge();
            __delay_us(5);
            Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;   //Continually read rotary value until it increases to 10 degrees
            while (Rotary_value < 20){
                ADC_ConversionStart();
                __delay_ms(1);
                Rotary_value = ADC_ConversionResultGet()/16;
            }
            
            Rotary_previous = 0;
            x = 0;
            printf("Sensor 1 Calibration:\n\r");
            printf("Closed: %d\n\r", Sensor1_initial);
            while (Rotary_value < 240){                    //Store values of sensor 1 until door is fully open
                ADC_SampleCapacitorDischarge();
                __delay_us(5);
                Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;
                if (abs(Rotary_value - Rotary_previous) > 10){
                    x = x+1;
                    Rotary_previous = Rotary_value;
                    ADC_SampleCapacitorDischarge();
                    __delay_us(5);
                    Sensor1_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA0);
                    Sensor1_index[x] = Sensor1_value;
                    printf("At %d:   %d\n\r", Rotary_value, Sensor1_value);
                }
            }
            
            ADC_SampleCapacitorDischarge();
            __delay_us(5);
            Sensor2_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA1);  //Store value of sensor 2 when door is fully open
            Sensor2_index[9] = Sensor2_value;
            printf("\n\rSensor 2 Calibration:\n\r");
            printf("Fully open:      %d\n\r", Sensor2_value);
            
            while (Rotary_value > 240){                  //Continually read rotary value until it decreases to 80 degrees
                ADC_SampleCapacitorDischarge();
                __delay_us(5);
                Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;
            }
            
            while (Rotary_value>35){                    //Store values of sensor 2 until door is fully closed
                ADC_SampleCapacitorDischarge();
                __delay_us(5);
                Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;
                if (abs(Rotary_value - Rotary_previous) > 10){
                    x = x-1;
                    Rotary_previous = Rotary_value;
                    ADC_SampleCapacitorDischarge();
                    __delay_us(5);
                    Sensor2_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA1);
                    Sensor2_index[x] = Sensor2_value;
                    printf("At %d:   %d\n\r", Rotary_value, Sensor2_value);
                }
            }
             printf("Closed: %d\n\r", Sensor2_initial);
        }   //End Calibration
        
        ADC_SampleCapacitorDischarge();                 //Read both sensors' values
        __delay_us(5);
        Sensor1_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA0);
        ADC_SampleCapacitorDischarge();
        __delay_us(5);
        Sensor2_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA1);
        
        if ((abs(Sensor2_initial - Sensor2_value) > 300)||(abs(Sensor1_initial - Sensor1_value) > 300)){   //If either sensor value does not match closed value, tell motor to begin rotation
            LED_DEBUG_SetHigh();
            __delay_ms(500);
            LED_DEBUG_SetLow();
            printf("\n\rInitial Values vs Current Values:\n\r");
            printf("Sensor 1:\n\r");
            printf("%d vs %d\n\r", Sensor1_initial, Sensor1_value);
            printf("\n\rSensor 2:\n\r");
            printf("%d vs %d\n\r", Sensor2_initial, Sensor2_value);
            SENSOR2_STATUS_SetHigh();
            ADC_SampleCapacitorDischarge();             //Continually read rotary value until it increases to 10 degrees
            __delay_us(5);
            Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;
            while (Rotary_value < 20){
                ADC_ConversionStart();
                __delay_ms(1);
                Rotary_value = ADC_ConversionResultGet()/16;
            }
            
            Rotary_previous = 0;
            x = 0;
            while (Rotary_value<240){                    //Check values of sensor 1 with stored values as door opens
                ADC_SampleCapacitorDischarge();
                __delay_us(5);
                Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;
                if (abs(Rotary_value - Rotary_previous) > 10){
                    x = x+1;
                    Rotary_previous = Rotary_value;
                    ADC_SampleCapacitorDischarge();
                    __delay_us(5);
                    Sensor1_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA0);
                    while (abs(Sensor1_index[x] - Sensor1_value) > 300){    //If values do not match, tell motor to stop, wait 2 seconds, then check again
                        printf("\n\rExpected Value vs Current Value:\n\r");
                        printf("%d vs %d\n\r", Sensor1_index[x], Sensor1_value);
                        SENSOR1_STATUS_SetHigh();
                        LED_DEBUG_SetHigh();
                        __delay_ms(2000);
                        ADC_ConversionStart();
                        __delay_ms(1);
                        Sensor1_value = ADC_ConversionResultGet();
                    }
                    SENSOR1_STATUS_SetLow();
                    LED_DEBUG_SetLow();
                }
            }
            
            SENSOR2_STATUS_SetLow();
            Rotary_value = 255;
            Rotary_previous = 255;
            x = 9;
            ADC_SampleCapacitorDischarge();             //Continually read rotary value until it decreases to 80 degrees
            __delay_us(5);
            Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;
            while (Rotary_value > 240){
                ADC_ConversionStart();
                __delay_ms(1);
                Rotary_value = ADC_ConversionResultGet()/16;
            }
            
            while (Rotary_value>35){                    //Check values of sensor 2 with stored values as door closes
                ADC_SampleCapacitorDischarge();
                __delay_us(5);
                Rotary_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA2)/16;
                if (abs(Rotary_value - Rotary_previous) > 10){
                    x = x-1;
                    Rotary_previous = Rotary_value;
                    ADC_SampleCapacitorDischarge();
                    __delay_us(5);
                    Sensor2_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA1);
                    while (abs(Sensor2_index[x] - Sensor2_value) > 300){    //If values do not match, tell motor to stop, wait 2 seconds, then check again
                        printf("\n\rExpected Value vs Current Value:\n\r");
                        printf("%d vs %d\n\r", Sensor2_index[x], Sensor2_value);
                        SENSOR2_STATUS_SetHigh();
                        LED_DEBUG_SetHigh();
                        __delay_ms(2000);
                        ADC_ConversionStart();
                        __delay_ms(1);
                        Sensor2_value = ADC_ConversionResultGet();
                    }
                    SENSOR2_STATUS_SetLow();
                    LED_DEBUG_SetLow();
                }
            }
            
            while (MOTOR_INPUT_GetValue() == 1){        //Wait until motor finishes closing, then revert to default sensor state
            }
            SENSOR1_STATUS_SetLow();
            SENSOR2_STATUS_SetLow();
        }
        
        if (CALIBRATE_GetValue() == 1){                   //If calibration input is received, repeat calibration on next loop
            calibrate = 1;
        }
    }    
}