/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define SENSOR1_TRIS                 TRISAbits.TRISA0
#define SENSOR1_LAT                  LATAbits.LATA0
#define SENSOR1_PORT                 PORTAbits.RA0
#define SENSOR1_WPU                  WPUAbits.WPUA0
#define SENSOR1_OD                   ODCONAbits.ODCA0
#define SENSOR1_ANS                  ANSELAbits.ANSELA0
#define SENSOR1_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define SENSOR1_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define SENSOR1_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define SENSOR1_GetValue()           PORTAbits.RA0
#define SENSOR1_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define SENSOR1_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define SENSOR1_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define SENSOR1_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define SENSOR1_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define SENSOR1_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define SENSOR1_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define SENSOR1_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA1 aliases
#define SENSOR2_TRIS                 TRISAbits.TRISA1
#define SENSOR2_LAT                  LATAbits.LATA1
#define SENSOR2_PORT                 PORTAbits.RA1
#define SENSOR2_WPU                  WPUAbits.WPUA1
#define SENSOR2_OD                   ODCONAbits.ODCA1
#define SENSOR2_ANS                  ANSELAbits.ANSELA1
#define SENSOR2_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define SENSOR2_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define SENSOR2_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define SENSOR2_GetValue()           PORTAbits.RA1
#define SENSOR2_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define SENSOR2_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define SENSOR2_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define SENSOR2_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define SENSOR2_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define SENSOR2_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define SENSOR2_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define SENSOR2_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RB5 aliases
#define MOTOR_INPUT_TRIS                 TRISBbits.TRISB5
#define MOTOR_INPUT_LAT                  LATBbits.LATB5
#define MOTOR_INPUT_PORT                 PORTBbits.RB5
#define MOTOR_INPUT_WPU                  WPUBbits.WPUB5
#define MOTOR_INPUT_OD                   ODCONBbits.ODCB5
#define MOTOR_INPUT_ANS                  ANSELBbits.ANSELB5
#define MOTOR_INPUT_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define MOTOR_INPUT_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define MOTOR_INPUT_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define MOTOR_INPUT_GetValue()           PORTBbits.RB5
#define MOTOR_INPUT_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define MOTOR_INPUT_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define MOTOR_INPUT_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define MOTOR_INPUT_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define MOTOR_INPUT_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define MOTOR_INPUT_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define MOTOR_INPUT_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define MOTOR_INPUT_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RD5 aliases
#define SENSOR2_STATUS_TRIS                 TRISDbits.TRISD5
#define SENSOR2_STATUS_LAT                  LATDbits.LATD5
#define SENSOR2_STATUS_PORT                 PORTDbits.RD5
#define SENSOR2_STATUS_WPU                  WPUDbits.WPUD5
#define SENSOR2_STATUS_OD                   ODCONDbits.ODCD5
#define SENSOR2_STATUS_ANS                  ANSELDbits.ANSELD5
#define SENSOR2_STATUS_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define SENSOR2_STATUS_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define SENSOR2_STATUS_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define SENSOR2_STATUS_GetValue()           PORTDbits.RD5
#define SENSOR2_STATUS_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define SENSOR2_STATUS_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define SENSOR2_STATUS_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define SENSOR2_STATUS_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define SENSOR2_STATUS_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define SENSOR2_STATUS_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define SENSOR2_STATUS_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define SENSOR2_STATUS_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RD6 aliases
#define SENSOR1_STATUS_TRIS                 TRISDbits.TRISD6
#define SENSOR1_STATUS_LAT                  LATDbits.LATD6
#define SENSOR1_STATUS_PORT                 PORTDbits.RD6
#define SENSOR1_STATUS_WPU                  WPUDbits.WPUD6
#define SENSOR1_STATUS_OD                   ODCONDbits.ODCD6
#define SENSOR1_STATUS_ANS                  ANSELDbits.ANSELD6
#define SENSOR1_STATUS_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define SENSOR1_STATUS_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define SENSOR1_STATUS_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define SENSOR1_STATUS_GetValue()           PORTDbits.RD6
#define SENSOR1_STATUS_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define SENSOR1_STATUS_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define SENSOR1_STATUS_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define SENSOR1_STATUS_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define SENSOR1_STATUS_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define SENSOR1_STATUS_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define SENSOR1_STATUS_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define SENSOR1_STATUS_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RE0 aliases
#define LED_DEBUG_TRIS                 TRISEbits.TRISE0
#define LED_DEBUG_LAT                  LATEbits.LATE0
#define LED_DEBUG_PORT                 PORTEbits.RE0
#define LED_DEBUG_WPU                  WPUEbits.WPUE0
#define LED_DEBUG_OD                   ODCONEbits.ODCE0
#define LED_DEBUG_ANS                  ANSELEbits.ANSELE0
#define LED_DEBUG_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define LED_DEBUG_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define LED_DEBUG_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define LED_DEBUG_GetValue()           PORTEbits.RE0
#define LED_DEBUG_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define LED_DEBUG_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define LED_DEBUG_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define LED_DEBUG_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define LED_DEBUG_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define LED_DEBUG_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define LED_DEBUG_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define LED_DEBUG_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set RE1 aliases
#define BUTTON_DEBUG_TRIS                 TRISEbits.TRISE1
#define BUTTON_DEBUG_LAT                  LATEbits.LATE1
#define BUTTON_DEBUG_PORT                 PORTEbits.RE1
#define BUTTON_DEBUG_WPU                  WPUEbits.WPUE1
#define BUTTON_DEBUG_OD                   ODCONEbits.ODCE1
#define BUTTON_DEBUG_ANS                  ANSELEbits.ANSELE1
#define BUTTON_DEBUG_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define BUTTON_DEBUG_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define BUTTON_DEBUG_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define BUTTON_DEBUG_GetValue()           PORTEbits.RE1
#define BUTTON_DEBUG_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define BUTTON_DEBUG_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define BUTTON_DEBUG_SetPullup()          do { WPUEbits.WPUE1 = 1; } while(0)
#define BUTTON_DEBUG_ResetPullup()        do { WPUEbits.WPUE1 = 0; } while(0)
#define BUTTON_DEBUG_SetPushPull()        do { ODCONEbits.ODCE1 = 0; } while(0)
#define BUTTON_DEBUG_SetOpenDrain()       do { ODCONEbits.ODCE1 = 1; } while(0)
#define BUTTON_DEBUG_SetAnalogMode()      do { ANSELEbits.ANSELE1 = 1; } while(0)
#define BUTTON_DEBUG_SetDigitalMode()     do { ANSELEbits.ANSELE1 = 0; } while(0)

// get/set RF0 aliases
#define IO_RF0_TRIS                 TRISFbits.TRISF0
#define IO_RF0_LAT                  LATFbits.LATF0
#define IO_RF0_PORT                 PORTFbits.RF0
#define IO_RF0_WPU                  WPUFbits.WPUF0
#define IO_RF0_OD                   ODCONFbits.ODCF0
#define IO_RF0_ANS                  ANSELFbits.ANSELF0
#define IO_RF0_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define IO_RF0_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define IO_RF0_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define IO_RF0_GetValue()           PORTFbits.RF0
#define IO_RF0_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define IO_RF0_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define IO_RF0_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define IO_RF0_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define IO_RF0_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define IO_RF0_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define IO_RF0_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define IO_RF0_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define IO_RF1_TRIS                 TRISFbits.TRISF1
#define IO_RF1_LAT                  LATFbits.LATF1
#define IO_RF1_PORT                 PORTFbits.RF1
#define IO_RF1_WPU                  WPUFbits.WPUF1
#define IO_RF1_OD                   ODCONFbits.ODCF1
#define IO_RF1_ANS                  ANSELFbits.ANSELF1
#define IO_RF1_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define IO_RF1_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define IO_RF1_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define IO_RF1_GetValue()           PORTFbits.RF1
#define IO_RF1_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define IO_RF1_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define IO_RF1_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define IO_RF1_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define IO_RF1_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define IO_RF1_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define IO_RF1_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define IO_RF1_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

// get/set RF7 aliases
#define CALIBRATE_TRIS                 TRISFbits.TRISF7
#define CALIBRATE_LAT                  LATFbits.LATF7
#define CALIBRATE_PORT                 PORTFbits.RF7
#define CALIBRATE_WPU                  WPUFbits.WPUF7
#define CALIBRATE_OD                   ODCONFbits.ODCF7
#define CALIBRATE_ANS                  ANSELFbits.ANSELF7
#define CALIBRATE_SetHigh()            do { LATFbits.LATF7 = 1; } while(0)
#define CALIBRATE_SetLow()             do { LATFbits.LATF7 = 0; } while(0)
#define CALIBRATE_Toggle()             do { LATFbits.LATF7 = ~LATFbits.LATF7; } while(0)
#define CALIBRATE_GetValue()           PORTFbits.RF7
#define CALIBRATE_SetDigitalInput()    do { TRISFbits.TRISF7 = 1; } while(0)
#define CALIBRATE_SetDigitalOutput()   do { TRISFbits.TRISF7 = 0; } while(0)
#define CALIBRATE_SetPullup()          do { WPUFbits.WPUF7 = 1; } while(0)
#define CALIBRATE_ResetPullup()        do { WPUFbits.WPUF7 = 0; } while(0)
#define CALIBRATE_SetPushPull()        do { ODCONFbits.ODCF7 = 0; } while(0)
#define CALIBRATE_SetOpenDrain()       do { ODCONFbits.ODCF7 = 1; } while(0)
#define CALIBRATE_SetAnalogMode()      do { ANSELFbits.ANSELF7 = 1; } while(0)
#define CALIBRATE_SetDigitalMode()     do { ANSELFbits.ANSELF7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/